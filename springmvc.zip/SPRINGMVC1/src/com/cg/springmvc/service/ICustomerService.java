package com.cg.springmvc.service;

import com.cg.springmvc.bean.Customer;

public interface ICustomerService {
	public Customer addCustomer(Customer customer);

}
