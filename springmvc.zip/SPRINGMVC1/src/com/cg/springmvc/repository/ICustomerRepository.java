package com.cg.springmvc.repository;

import com.cg.springmvc.bean.Customer;

public interface ICustomerRepository {
	public Customer addCustomer(Customer customer);

}
